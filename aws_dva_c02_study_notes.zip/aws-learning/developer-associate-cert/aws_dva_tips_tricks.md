# AWS DVA-C02 Exam Tips & Tricks
Danh sách tổng hợp từ quá trình luyện đề thực tế.

## 📌 Domain 2: Security (Serverless Security)

### 🧩 Topic: AWS Lambda Code Integrity & Security

#### 🔑 Keywords Nhận Diện
* `unauthorized changes to the code` (thay đổi code trái phép).
* `ensure only trusted code is deployed` (đảm bảo chỉ deploy code đáng tin cậy).
* `digitally sign the Lambda package` (ký số gói deploy).

#### 💡 Tip & Trick Chọn Đáp Án
* **AWS Signer + Lambda Code Signing:** Khi đề bài đề cập đến việc chống chỉnh sửa code Lambda trái phép hoặc chỉ cho phép deploy code đã qua kiểm duyệt/tin tưởng -> Hãy tìm đáp án chứa bộ đôi **AWS Signer** và **Code Signing configuration** trên Lambda.
* **Bẫy KMS:** AWS KMS rất mạnh về mã hóa dữ liệu (Encryption) nhưng đối với bài toán xác thực tính toàn vẹn và nguồn gốc của gói deploy (Code Integrity), dịch vụ quản lý chữ ký chuẩn mã nguồn của AWS luôn là **AWS Signer**.
* **Bẫy CodeDeploy:** CodeDeploy quản lý luồng deploy (Linear, Canary, AllAtOnce) chứ không trực tiếp ký số hay xác thực tính an toàn của nội dung file code trước khi nạp vào Lambda.

---

## 📌 Domain 3: Development with AWS Services (Serverless & Integration)

### 🧩 Topic: AWS Lambda Invocation Tracking & Messaging

#### 🔑 Keywords Nhận Diện
* `each Lambda function invocation` / `record of each invocation`: Cần ghi nhận lại mọi lượt thực thi của Lambda (cả thành công và thất bại).
* `add a record to an Amazon SQS queue`: Đưa thông tin vào hàng đợi SQS.

#### 💡 Tip & Trick Chọn Đáp Án
* **Bản chất nghiệp vụ (Application Logic):** Khi đề bài yêu cầu ghi nhận thông tin cụ thể hoặc custom chi tiết của *mỗi lượt chạy* vào một dịch vụ khác (như SQS), cách trực tiếp và linh hoạt nhất là sử dụng **AWS SDK** (`SendMessage` API) ngay trong mã nguồn Lambda.
* **Loại trừ DLQ (Dead-Letter Queue):** DLQ **chỉ** hoạt động khi invocation bị **thất bại** (failed) sau khi đã re-try. Nếu đề bài yêu cầu "each invocation" hoặc "successful invocation", loại ngay đáp án có DLQ.
* **Cảnh giác với Destinations:** Lambda Destinations (`OnSuccess` / `OnFailure`) rất tốt cho luồng async event-driven, nhưng nếu đề bài đi kèm các cấu hình rườm rà không cần thiết (như tạo CloudWatch Alarm chỉ để check delivery fail của destination trong khi mục đích chính là record invocation) -> Ưu tiên giải pháp xử lý bằng code SDK ở cuối function để đảm bảo tính tường minh.
