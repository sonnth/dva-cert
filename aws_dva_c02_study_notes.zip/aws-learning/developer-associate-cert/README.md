# AWS Certified Developer – Associate (DVA-C02) Study Note

Chào bạn Bách, đây là tài liệu tổng hợp lộ trình và các Tip & Trick được đúc kết trực tiếp từ các câu hỏi luyện đề của bạn.

## 📌 Cấu Trúc Đề Thi DVA-C02
* **Domain 1: Deployment** (22%) - CI/CD, Beanstalk, CloudFormation.
* **Domain 2: Security** (26%) - IAM, KMS, Secrets Manager, Cognito, SSM.
* **Domain 3: Development with AWS Services** (30%) - Serverless, DynamoDB, SQS, SNS, Kinesis.
* **Domain 4: Refactoring & Troubleshooting** (22%) - CloudWatch, X-Ray, CloudTrail.
